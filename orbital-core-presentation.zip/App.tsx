
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { generatePresentationContent, generateSlideImage } from './services/gemini';
import { PresentationData, GenerationStatus } from './types';
import { BASE_ROTATION_SPEED, MAX_SPEED_MODIFIER, ORBIT_RADIUS_X, ORBIT_RADIUS_Z, SPIRAL_AMPLITUDE, COSMIC_THEMES } from './constants';
import SlideView from './components/SlideView';
import Background3D from './components/Background3D';
import CosmicCenter from './components/CosmicCenter';

const App: React.FC = () => {
  const [prompt, setPrompt] = useState(COSMIC_THEMES[0]);
  const [status, setStatus] = useState<GenerationStatus>('idle');
  const [presentation, setPresentation] = useState<PresentationData | null>(null);
  const [currentZoomedIndex, setCurrentZoomedIndex] = useState<number | null>(null);
  const [rotationAngle, setRotationAngle] = useState(0);
  const [errorMsg, setErrorMsg] = useState('');
  const [showPromptInput, setShowPromptInput] = useState(true);
  
  const speedRef = useRef<number>(BASE_ROTATION_SPEED);
  const requestRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);

  const handleGenerate = async (targetPrompt: string) => {
    if (!targetPrompt.trim()) return;
    
    try {
      setShowPromptInput(false);
      setStatus('generating_content');
      setErrorMsg('');
      
      const data = await generatePresentationContent(targetPrompt);
      const initialSlides = data.slides.map(s => ({ ...s, imageUrl: '' }));
      setPresentation({ ...data, slides: initialSlides });
      
      setStatus('generating_images');
      
      const slidesWithImages = [...initialSlides];
      for (let i = 0; i < slidesWithImages.length; i++) {
        try {
          const imageUrl = await generateSlideImage(slidesWithImages[i].visualPrompt);
          slidesWithImages[i] = { ...slidesWithImages[i], imageUrl };
          setPresentation(prev => prev ? { ...prev, slides: [...slidesWithImages] } : null);
        } catch (imgErr) {
          console.warn(`Imagery failure for slide ${i}:`, imgErr);
        }
        await new Promise(resolve => setTimeout(resolve, 400));
      }
      
      setStatus('ready');
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Quantum disruption detected. Please restart link.');
      setStatus('error');
    }
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const centerX = window.innerWidth / 2;
      const dist = (e.clientX - centerX) / (centerX || 1); 
      speedRef.current = BASE_ROTATION_SPEED + (dist * MAX_SPEED_MODIFIER);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const animate = useCallback((time: number) => {
    const deltaTime = time - (lastTimeRef.current || time);
    lastTimeRef.current = time;

    if (currentZoomedIndex === null && status !== 'idle' && !showPromptInput) {
      setRotationAngle(prev => prev + (speedRef.current * (deltaTime / 16)));
    }
    requestRef.current = requestAnimationFrame(animate);
  }, [currentZoomedIndex, status, showPromptInput]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(requestRef.current);
  }, [animate]);

  const toggleZoom = (index: number) => {
    setCurrentZoomedIndex(currentZoomedIndex === index ? null : index);
  };

  const handleReset = () => {
    setPresentation(null);
    setCurrentZoomedIndex(null);
    setStatus('idle');
    setShowPromptInput(true);
    setRotationAngle(0);
  };

  const isZoomed = currentZoomedIndex !== null;

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden flex flex-col font-inter text-white selection:bg-blue-500/30">
      <Background3D />

      <header className={`relative z-50 p-4 flex items-center justify-between transition-all duration-1000 ${isZoomed ? 'opacity-0 -translate-y-10' : 'opacity-100 translate-y-0'}`}>
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 relative group cursor-pointer" onClick={handleReset}>
             <div className="absolute inset-0 bg-blue-600 rounded rotate-45 animate-pulse" />
             <div className="absolute inset-0.5 bg-black rounded rotate-45 border border-white/20" />
          </div>
          <h1 className="text-xs font-orbitron font-black tracking-[0.2em] text-white uppercase">
            ORBITAL <span className="text-blue-500">CORE</span>
          </h1>
        </div>

        <div className="flex items-center gap-3">
          {status === 'generating_images' && (
            <div className="px-2 py-0.5 border border-blue-500/10 rounded-full bg-blue-500/5">
              <span className="text-[6px] font-orbitron text-blue-400 tracking-[0.1em] uppercase">Neural Feed Active</span>
            </div>
          )}
          {!showPromptInput && (
            <button 
              onClick={handleReset}
              className="px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full transition-all text-[6px] font-orbitron tracking-[0.1em] uppercase text-gray-400"
            >
               Reset Link
            </button>
          )}
        </div>
      </header>

      <main className="relative flex-grow flex items-center justify-center perspective-container">
        {!showPromptInput && status !== 'error' && (
          <div className={`transition-all duration-1000 ${isZoomed ? 'opacity-0 scale-50 blur-3xl' : 'opacity-100 scale-100'}`}>
            <CosmicCenter />
          </div>
        )}

        {showPromptInput && (
          <div className="relative z-50 w-full max-w-lg p-4 animate-in fade-in zoom-in slide-in-from-bottom-8 duration-700">
            <div className="bg-black/95 backdrop-blur-3xl border border-white/10 rounded-xl p-6 shadow-2xl relative overflow-hidden">
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-600/5 blur-[60px] rounded-full" />
              
              <div className="text-center mb-5">
                <h2 className="text-base font-orbitron font-black tracking-[0.2em] text-white uppercase mb-2">
                  INITIATE SYSTEM
                </h2>
                <div className="w-10 h-0.5 bg-blue-500 mx-auto rounded-full" />
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="text-[6px] font-orbitron text-blue-400 tracking-[0.2em] uppercase mb-1.5 block font-black">Visual Target</label>
                  <input 
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white font-light focus:outline-none focus:border-blue-500/50 transition-all text-sm placeholder:text-white/10"
                    placeholder="Coordinate..."
                    onKeyDown={(e) => e.key === 'Enter' && handleGenerate(prompt)}
                  />
                </div>

                <div className="grid grid-cols-1 gap-1">
                  {COSMIC_THEMES.map((theme, i) => (
                    <button
                      key={i}
                      onClick={() => setPrompt(theme)}
                      className={`text-left text-[7px] p-2 rounded-md border transition-all font-orbitron tracking-[0.1em] uppercase ${prompt === theme ? 'bg-blue-600/10 border-blue-400/40 text-blue-200' : 'bg-white/5 border-white/5 text-gray-500 hover:border-white/20'}`}
                    >
                      {theme}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => handleGenerate(prompt)}
                  disabled={!prompt.trim() || status !== 'idle'}
                  className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-20 text-white font-orbitron font-black py-3 rounded-lg transition-all tracking-[0.4em] text-[8px] uppercase active:scale-[0.98]"
                >
                  START NEURAL SYNC
                </button>
              </div>
            </div>
          </div>
        )}

        {status === 'generating_content' && (
          <div className="relative z-50 flex flex-col items-center gap-4">
             <div className="relative w-10 h-10">
               <div className="absolute inset-0 border-2 border-blue-500/10 rounded-full" />
               <div className="absolute inset-0 border-t-2 border-blue-400 rounded-full animate-spin" />
             </div>
             <p className="text-[10px] font-orbitron text-white tracking-[0.2em] uppercase animate-pulse">Analyzing...</p>
          </div>
        )}

        {presentation && !showPromptInput && (
          <div className="w-full h-full relative" style={{ transformStyle: 'preserve-3d' }}>
            {presentation.slides.map((slide, idx) => {
              const slideCount = presentation.slides.length;
              const angle = rotationAngle + (idx * (2 * Math.PI / slideCount));
              
              const x = Math.sin(angle) * ORBIT_RADIUS_X;
              const z = Math.cos(angle) * ORBIT_RADIUS_Z;
              
              // Centering the spiral vertically around 0 to align with the star stream
              const y = Math.sin(angle) * SPIRAL_AMPLITUDE;
              
              const normalizedZ = (z + ORBIT_RADIUS_Z) / (2 * ORBIT_RADIUS_Z); 
              const scale = 0.5 + (normalizedZ * 0.5); 
              const opacity = 0.2 + (normalizedZ * 0.8);

              const isThisCardZoomed = currentZoomedIndex === idx;
              const isOtherCardZoomed = currentZoomedIndex !== null && !isThisCardZoomed;

              return (
                <div key={slide.id} className={`transition-all duration-1000 ${isOtherCardZoomed ? 'opacity-0 blur-3xl scale-50 pointer-events-none' : 'opacity-100'}`}>
                  <SlideView 
                    slide={slide} 
                    x={x}
                    y={y}
                    z={z}
                    scale={scale}
                    opacity={opacity}
                    isZoomed={isThisCardZoomed}
                    onToggleZoom={() => toggleZoom(idx)}
                  />
                </div>
              );
            })}
          </div>
        )}

        {status === 'error' && (
          <div className="relative z-50 text-center bg-red-950/20 backdrop-blur-xl p-5 rounded-xl border border-red-500/20 max-w-xs">
             <p className="text-red-400 text-[8px] font-orbitron mb-4 tracking-[0.1em] uppercase">{errorMsg}</p>
             <button 
               onClick={handleReset} 
               className="px-5 py-2 bg-red-600 text-white rounded text-[7px] font-orbitron tracking-[0.2em] uppercase"
              >
                REBOOT
              </button>
          </div>
        )}
      </main>

      {status === 'ready' && !isZoomed && (
        <div className="absolute bottom-8 left-0 right-0 z-50 flex flex-col items-center pointer-events-none">
          <div className="px-4 py-2 bg-black/60 backdrop-blur-xl border border-white/5 rounded-full shadow-lg">
             <span className="text-[6px] text-blue-300 font-orbitron tracking-[0.2em] uppercase font-black">
               AXIAL ROTATION ACTIVE • SELECT MODULE
             </span>
          </div>
        </div>
      )}

      {isZoomed && (
        <button 
          onClick={() => setCurrentZoomedIndex(null)}
          className="absolute top-4 right-4 z-[110] w-7 h-7 rounded-full bg-black/80 backdrop-blur-xl border border-white/10 flex items-center justify-center hover:bg-blue-600/20 transition-all group"
        >
          <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      )}

      <footer className={`relative z-50 p-4 flex justify-between items-center text-[5px] font-orbitron text-gray-700 tracking-[0.1em] uppercase transition-all duration-1000 ${isZoomed ? 'opacity-0' : 'opacity-100'}`}>
        <span>LINK: STABLE</span>
        <span>RADIAL_V: {speedRef.current.toFixed(6)}</span>
      </footer>
    </div>
  );
};

export default App;
