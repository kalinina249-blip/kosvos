
import React from 'react';
import { Slide } from '../types';

interface SlideViewProps {
  slide: Slide;
  x: number;
  y: number;
  z: number;
  scale: number;
  opacity: number;
  isZoomed: boolean;
  onToggleZoom: () => void;
}

const SlideView: React.FC<SlideViewProps> = ({ 
  slide, 
  x, 
  y,
  z, 
  scale, 
  opacity, 
  isZoomed, 
  onToggleZoom 
}) => {
  // Resetting all offsets when zoomed to place the card dead center
  const transform = isZoomed 
    ? 'translate3d(0, 0, 600px) scale(1)' 
    : `translate3d(${x}px, ${y}px, ${z}px) scale(${scale})`;

  return (
    <>
      {/* Cinematic focus backdrop */}
      {isZoomed && (
        <div 
          className="fixed inset-0 bg-black/95 backdrop-blur-3xl z-[90] transition-opacity duration-1000 animate-in fade-in"
          onClick={onToggleZoom}
        />
      )}

      <div 
        className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-all duration-[1000ms] cubic-bezier(0.19, 1, 0.22, 1) cursor-pointer group ${isZoomed ? 'z-[100] w-[340px]' : 'w-[200px]'}`}
        style={{ 
          transform,
          opacity: isZoomed ? 1 : opacity,
          pointerEvents: isZoomed || opacity > 0.4 ? 'auto' : 'none',
          filter: !isZoomed ? `blur(${(1 - opacity) * 1.5}px)` : 'none'
        }}
        onClick={(e) => {
          if (!isZoomed) onToggleZoom();
          e.stopPropagation();
        }}
      >
        <div className={`relative bg-black/90 backdrop-blur-3xl border border-white/10 rounded-xl overflow-hidden shadow-2xl transition-all duration-1000 ${!isZoomed ? 'group-hover:border-blue-400/60 group-hover:bg-black/60' : 'border-blue-500/50 shadow-[0_0_100px_rgba(0,0,0,1)]'}`}>
          
          {/* Visual Container */}
          <div className="aspect-[16/10] relative overflow-hidden bg-white/5 border-b border-white/5">
            {!slide.imageUrl ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-blue-500/10 border-t-blue-400 rounded-full animate-spin" />
                <span className="text-[5px] font-orbitron text-blue-400/40 uppercase tracking-[0.1em]">Syncing...</span>
              </div>
            ) : (
              <img 
                src={slide.imageUrl} 
                alt={slide.title}
                className="w-full h-full object-cover transition-transform duration-[8s] group-hover:scale-110"
              />
            )}
            
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/5 to-transparent opacity-80" />
            
            <div className="absolute bottom-0 left-0 right-0 p-3">
              <h3 className={`${isZoomed ? 'text-base' : 'text-[10px]'} font-orbitron font-bold text-white tracking-tight leading-tight transition-all duration-1000`}>
                {slide.title}
              </h3>
            </div>
          </div>

          {/* Content Area */}
          <div className="p-3 relative">
            <p className={`${isZoomed ? 'text-[10px] leading-relaxed mb-3' : 'text-[8px] leading-relaxed line-clamp-2 mb-2'} text-gray-400 font-light transition-all duration-1000`}>
              {slide.content}
            </p>
            
            <div className="flex items-center justify-between opacity-40 pt-2 border-t border-white/5">
              <div className="flex flex-col">
                <span className="text-[5px] font-orbitron text-blue-400 uppercase tracking-[0.2em]">Link</span>
                <span className="text-[6px] font-mono text-white/40 tracking-[0.1em]">{slide.id.slice(0,6).toUpperCase()}</span>
              </div>
              
              {isZoomed && (
                 <button 
                   onClick={(e) => { e.stopPropagation(); onToggleZoom(); }}
                   className="px-3 py-1 bg-blue-600/20 hover:bg-blue-600/40 border border-blue-500/40 rounded text-[6px] font-orbitron text-blue-300 font-bold tracking-[0.1em] transition-all uppercase"
                 >
                   Return
                 </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SlideView;
