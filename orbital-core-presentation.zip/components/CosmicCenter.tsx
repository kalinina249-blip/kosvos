
import React from 'react';

const CosmicCenter: React.FC = () => {
  return (
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
      <div className="relative w-24 h-24">
        {/* Deep Field Glow */}
        <div className="absolute -inset-20 bg-blue-900/10 rounded-full blur-[60px]" />
        
        {/* Primary Singularity */}
        <div className="absolute inset-0 bg-blue-600 rounded-full blur-[30px] opacity-10 animate-pulse" />
        <div className="absolute inset-6 bg-blue-400/30 rounded-full blur-[15px] opacity-40" />
        <div className="absolute inset-[46%] bg-white rounded-full blur-[1px] opacity-90 shadow-[0_0_20px_rgba(59,130,246,1)]" />
        
        {/* Intricate Orbital Rings */}
        <div className="absolute -inset-4 border-[0.5px] border-blue-500/15 rounded-full animate-[spin_8s_linear_infinite]" />
        <div className="absolute -inset-8 border-[0.5px] border-blue-400/10 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
        
        {/* Data Stream Rays */}
        {[...Array(16)].map((_, i) => (
          <div 
            key={i}
            className="absolute top-1/2 left-1/2 w-[400px] h-[0.5px] bg-gradient-to-r from-blue-500/20 via-blue-400/5 to-transparent origin-left"
            style={{ transform: `rotate(${i * 22.5}deg) translateX(20px)` }}
          />
        ))}
      </div>
    </div>
  );
};

export default CosmicCenter;
