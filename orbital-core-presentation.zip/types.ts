
export interface Slide {
  id: string;
  title: string;
  content: string;
  visualPrompt: string;
  imageUrl?: string;
}

export interface PresentationData {
  title: string;
  slides: Slide[];
}

export type GenerationStatus = 'idle' | 'generating_content' | 'generating_images' | 'ready' | 'error';
