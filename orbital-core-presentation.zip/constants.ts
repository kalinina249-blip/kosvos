
export const BASE_ROTATION_SPEED = 0.0006;
export const MAX_SPEED_MODIFIER = 0.008; 
export const ORBIT_RADIUS_X = 320; // Slightly tighter for laptop screens
export const ORBIT_RADIUS_Z = 320; 
export const SPIRAL_AMPLITUDE = 80; // More subtle spiral to stay aligned with the flow

export const COSMIC_THEMES = [
  "Путешествие к центру вселенной: тайны времени и материи",
  "Колонизация Марса: от мечты к реальности",
  "Черные дыры: за горизонтом событий",
  "Эволюция звезд: рождение и смерть светил",
  "Поиск экзопланет: есть ли жизнь за пределами Земли?"
];
