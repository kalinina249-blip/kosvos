
import { GoogleGenAI, Type } from "@google/genai";
import { PresentationData } from "../types";

export const generatePresentationContent = async (prompt: string): Promise<PresentationData> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `You are an advanced cosmic AI. Create a cinematic, deeply informative presentation structure for the topic: "${prompt}".
    The presentation should consist of 7-9 slides. Each slide must include:
    1. A profound, punchy title.
    2. A technical yet poetic description (2-3 sentences).
    3. A specific English prompt for AI image generation that describes a hyper-detailed, epic, sci-fi cosmic landscape or conceptual technological scene.
    Output ONLY valid JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          slides: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                content: { type: Type.STRING },
                visualPrompt: { type: Type.STRING, description: 'A cinematic AI art prompt in English for space/tech imagery' }
              },
              required: ["id", "title", "content", "visualPrompt"]
            }
          }
        },
        required: ["title", "slides"]
      }
    }
  });

  try {
    const text = response.text.trim();
    // Clean potential markdown code blocks if the model ignored responseMimeType
    const jsonStr = text.startsWith('```') ? text.replace(/```json|```/g, '') : text;
    return JSON.parse(jsonStr);
  } catch (err) {
    console.error("Failed to parse presentation content:", err);
    throw new Error("Neural output corrupted. Re-trying may fix the alignment.");
  }
};

export const generateSlideImage = async (prompt: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { text: `An ultra-cinematic, photorealistic, 8k Resolution, wide aspect ratio masterpiece of cosmic concept art: ${prompt}. Incredible lighting, bioluminescent accents, deep space atmosphere, masterpiece, epic scale, high contrast.` }
      ]
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9"
      }
    }
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  
  // High-quality fallback if generation fails
  return `https://images.unsplash.com/photo-1462331940025-496dfbfc7564?q=80&w=1200&auto=format&fit=crop`;
};
